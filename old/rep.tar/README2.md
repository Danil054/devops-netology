1.  

- В чём отличие режимов работы сервисов в Docker Swarm кластере: replication и global?  
replication - указываем сколько экземпляров приложения необходимо держать запущенными в кластере.  
global - приложение запустится на каждой ноде кластера.  

- Какой алгоритм выбора лидера используется в Docker Swarm кластере?  
алгоритм поддержания распределенного консенсуса — Raft.  

- Что такое Overlay Network?  
Сеть, построенная поверх другой сети.  


2.  

Ноды: (https://github.com/Danil054/devops-netology/blob/main/pics/5.5-2.png)  

3.  
Сервисы: (https://github.com/Danil054/devops-netology/blob/main/pics/5.5-3.png)  

