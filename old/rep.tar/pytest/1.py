#!/usr/bin/env python3
a = 1
b = '2'
c = a + b
